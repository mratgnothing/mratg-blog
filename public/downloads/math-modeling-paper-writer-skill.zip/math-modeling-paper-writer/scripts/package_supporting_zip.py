#!/usr/bin/env python3
"""Build, validate, and safely replace a mathematical-modeling support ZIP."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import uuid
import zipfile
from pathlib import Path, PurePosixPath


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build a temporary ZIP, validate it, then safely replace the final ZIP."
    )
    parser.add_argument("--source", required=True, help="Support-material directory")
    parser.add_argument("--output", required=True, help="Final .zip path")
    parser.add_argument(
        "--include",
        action="append",
        default=[],
        help="Top-level source-relative item to include; repeat as needed. Default: all items.",
    )
    parser.add_argument("--expected-entry-count", type=int)
    parser.add_argument("--expected-root", action="append", default=[])
    parser.add_argument("--identity-token", action="append", default=[])
    parser.add_argument("--forbidden-text", action="append", default=[])
    parser.add_argument("--report", help="Optional JSON validation report")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def encoded_needles(tokens: list[str]) -> dict[str, list[bytes]]:
    result: dict[str, list[bytes]] = {}
    for token in tokens:
        variants: list[bytes] = []
        for encoding in ("utf-8", "gb18030", "utf-16-le", "utf-16-be"):
            try:
                value = token.encode(encoding)
            except UnicodeEncodeError:
                continue
            if value and value not in variants:
                variants.append(value)
        result[token] = variants
    return result


def collect_files(source: Path, includes: list[str]) -> list[tuple[Path, str]]:
    selected = includes or [item.name for item in source.iterdir()]
    files: list[tuple[Path, str]] = []
    for relative_text in sorted(selected, key=str.casefold):
        relative = Path(relative_text)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"Unsafe include path: {relative_text}")
        item = (source / relative).resolve(strict=True)
        if item != source and source not in item.parents:
            raise ValueError(f"Include escaped source directory: {relative_text}")
        if item.is_file():
            files.append((item, item.relative_to(source).as_posix()))
        elif item.is_dir():
            for child in sorted(
                (path for path in item.rglob("*") if path.is_file()),
                key=lambda path: path.relative_to(source).as_posix().casefold(),
            ):
                files.append((child, child.relative_to(source).as_posix()))
    if not files:
        raise ValueError("No files selected for the support ZIP")
    names = [name for _, name in files]
    if len(names) != len(set(names)):
        raise ValueError("Duplicate archive paths were selected")
    return files


def build_zip(source: Path, temporary: Path, includes: list[str]) -> None:
    files = collect_files(source, includes)
    with zipfile.ZipFile(
        temporary, mode="x", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path, archive_name in files:
            archive.write(path, archive_name)


def validate_zip(
    path: Path,
    expected_entry_count: int | None,
    expected_roots: list[str],
    identity_tokens: list[str],
    forbidden_texts: list[str],
) -> dict[str, object]:
    identity_needles = encoded_needles(identity_tokens)
    forbidden_needles = encoded_needles(forbidden_texts)
    identity_hits: list[dict[str, str]] = []
    forbidden_hits: list[dict[str, str]] = []

    # This context manager must exit before any final-path replacement.
    with zipfile.ZipFile(path, mode="r") as archive:
        bad_crc = archive.testzip()
        if bad_crc:
            raise ValueError(f"CRC failure in archive entry: {bad_crc}")
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise ValueError("ZIP contains duplicate entry names")
        for name in names:
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts or "\\" in name:
                raise ValueError(f"Unsafe or non-portable ZIP path: {name}")
        if expected_entry_count is not None and len(names) != expected_entry_count:
            raise ValueError(
                f"Expected {expected_entry_count} entries, found {len(names)}"
            )
        roots = sorted({name.split("/", 1)[0] for name in names if name})
        if expected_roots and set(roots) != set(expected_roots):
            raise ValueError(
                f"ZIP roots differ: expected {sorted(expected_roots)}, found {roots}"
            )
        for info in infos:
            if info.is_dir():
                continue
            payload = archive.read(info)
            for token, needles in identity_needles.items():
                if token in info.filename or any(needle in payload for needle in needles):
                    identity_hits.append({"entry": info.filename, "token": token})
            for token, needles in forbidden_needles.items():
                if token in info.filename or any(needle in payload for needle in needles):
                    forbidden_hits.append({"entry": info.filename, "text": token})

    if identity_hits:
        raise ValueError(f"Identity token hits: {identity_hits}")
    if forbidden_hits:
        raise ValueError(f"Forbidden text hits: {forbidden_hits}")
    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "entries": len(names),
        "roots": roots,
        "identity_hits": identity_hits,
        "forbidden_text_hits": forbidden_hits,
    }


def write_report(report_path: Path, payload: dict[str, object]) -> None:
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def main() -> int:
    args = parse_args()
    source = Path(args.source).expanduser().resolve(strict=True)
    output = Path(args.output).expanduser().resolve(strict=False)
    if not source.is_dir():
        raise ValueError(f"Source is not a directory: {source}")
    if output.suffix.lower() != ".zip":
        raise ValueError("Output must use the .zip extension")
    if output == source or source in output.parents:
        raise ValueError("Output ZIP cannot be inside the source directory")
    output.parent.mkdir(parents=True, exist_ok=True)

    token = uuid.uuid4().hex
    temporary = output.with_name(f".{output.stem}.{token}.new.zip")
    backup = output.with_name(f".{output.name}.{token}.backup")
    original_existed = output.exists()
    backup_ready = False
    output_replaced = False
    replacement_succeeded = False

    report_path = (
        Path(args.report).expanduser().resolve(strict=False) if args.report else None
    )
    if report_path == output:
        raise ValueError("Report path cannot be the same as the output ZIP")

    try:
        build_zip(source, temporary, args.include)
        temporary_report = validate_zip(
            temporary,
            args.expected_entry_count,
            args.expected_root,
            args.identity_token,
            args.forbidden_text,
        )

        if original_existed:
            shutil.copy2(output, backup)
            if sha256(backup) != sha256(output):
                raise ValueError("Recovery copy hash differs from the current final ZIP")
            backup_ready = True
        os.replace(temporary, output)
        output_replaced = True

        final_report = validate_zip(
            output,
            args.expected_entry_count,
            args.expected_root,
            args.identity_token,
            args.forbidden_text,
        )
        if final_report["sha256"] != temporary_report["sha256"]:
            raise ValueError("Final ZIP hash differs from the validated temporary ZIP")

        replacement_succeeded = True
        payload: dict[str, object] = {
            "status": "PASS",
            "source": str(source),
            "output": str(output),
            "previous_output_existed": original_existed,
            "validation": final_report,
        }
        if report_path:
            write_report(report_path, payload)
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0
    except Exception:
        if output_replaced and backup_ready and backup.exists():
            os.replace(backup, output)
        elif output_replaced and not original_existed and output.exists():
            output.unlink()
        raise
    finally:
        if temporary.exists():
            temporary.unlink()
        if replacement_succeeded and backup.exists():
            backup.unlink()
        if not output_replaced and backup.exists():
            backup.unlink()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)

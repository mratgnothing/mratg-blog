#!/usr/bin/env python3
"""Inventory installed fonts and block false exact-font claims."""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import sys
from pathlib import Path
from typing import Any, Iterable


FONT_SUFFIXES = {".ttf", ".otf", ".ttc", ".otc"}
KNOWN_WINDOWS_ALIASES: dict[str, tuple[str, ...]] = {
    "simsun": ("宋体",),
    "nsimsun": ("新宋体",),
    "simhei": ("黑体",),
    "fangsong": ("仿宋",),
    "kaiti": ("楷体",),
    "stzhongsong": ("华文中宋",),
    "stsong": ("华文宋体",),
    "stfangsong": ("华文仿宋",),
    "microsoftyahei": ("微软雅黑",),
}


def normalize(value: str) -> str:
    return re.sub(r"[\s_-]+", "", value).casefold()


def with_known_aliases(names: Iterable[str]) -> set[str]:
    expanded = {name for name in names if name}
    for name in list(expanded):
        expanded.update(KNOWN_WINDOWS_ALIASES.get(normalize(name), ()))
    return expanded


def font_directories() -> list[Path]:
    candidates: list[Path] = []
    system = platform.system()
    if system == "Windows":
        candidates.extend(
            [
                Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
                Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts",
            ]
        )
    elif system == "Darwin":
        candidates.extend(
            [Path("/System/Library/Fonts"), Path("/Library/Fonts"), Path.home() / "Library" / "Fonts"]
        )
    else:
        candidates.extend(
            [Path("/usr/share/fonts"), Path("/usr/local/share/fonts"), Path.home() / ".fonts"]
        )
    return [path for path in candidates if path.exists()]


def iter_font_files(directories: Iterable[Path]) -> Iterable[Path]:
    seen: set[Path] = set()
    for directory in directories:
        try:
            entries = directory.rglob("*")
            for path in entries:
                if path.suffix.casefold() in FONT_SUFFIXES and path not in seen:
                    seen.add(path)
                    yield path
        except (OSError, PermissionError):
            continue


def decode_name(record: Any) -> str:
    try:
        return record.toUnicode().strip()
    except Exception:
        try:
            encoding = record.getEncoding() or "utf-16-be"
            return record.string.decode(encoding, errors="replace").strip()
        except Exception:
            return ""


def names_from_ttfont(font: Any) -> set[str]:
    result: set[str] = set()
    if "name" not in font:
        return result
    # 1 family, 2 subfamily, 4 full name, 6 PostScript, 16 typographic family.
    for record in font["name"].names:
        if record.nameID in {1, 2, 4, 6, 16, 17}:
            value = decode_name(record)
            if value:
                result.add(value)
    return result


def inspect_font(path: Path) -> tuple[set[str], str | None]:
    try:
        from fontTools.ttLib import TTCollection, TTFont
    except ImportError:
        return {path.stem}, "fontTools unavailable; filename-only inspection"

    names: set[str] = set()
    try:
        if path.suffix.casefold() in {".ttc", ".otc"}:
            collection = TTCollection(str(path), lazy=True)
            try:
                for font in collection.fonts:
                    names.update(names_from_ttfont(font))
                    font.close()
            finally:
                collection.close()
        else:
            font = TTFont(str(path), lazy=True, fontNumber=0)
            try:
                names.update(names_from_ttfont(font))
            finally:
                font.close()
        names.add(path.stem)
        return names, None
    except Exception as exc:
        return {path.stem}, f"{type(exc).__name__}: {exc}"


def windows_registry_fonts() -> list[dict[str, Any]]:
    if platform.system() != "Windows":
        return []
    try:
        import winreg
    except ImportError:
        return []
    entries: list[dict[str, Any]] = []
    keys = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
    ]
    for hive, key_name in keys:
        try:
            with winreg.OpenKey(hive, key_name) as key:
                index = 0
                while True:
                    try:
                        display_name, file_value, _ = winreg.EnumValue(key, index)
                    except OSError:
                        break
                    index += 1
                    cleaned = re.sub(r"\s*\([^)]*(?:Type|Font)[^)]*\)\s*$", "", display_name, flags=re.I).strip()
                    names = {cleaned}
                    names.update(part.strip() for part in cleaned.split("&") if part.strip())
                    file_path = Path(str(file_value))
                    if not file_path.is_absolute():
                        system_path = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / file_path
                        user_path = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts" / file_path
                        file_path = system_path if system_path.exists() else user_path
                    entries.append({"path": str(file_path), "names": sorted(name for name in names if name)})
        except OSError:
            continue
    return entries


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require", action="append", default=[], help="Exact required family/full font name")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--font-dir", action="append", type=Path, default=[])
    args = parser.parse_args()

    directories = font_directories() + [path for path in args.font_dir if path.exists()]
    inventory: list[dict[str, Any]] = []
    name_index: dict[str, list[dict[str, str]]] = {}
    errors: list[dict[str, str]] = []
    fonttools_available = True

    for path in iter_font_files(directories):
        names, error = inspect_font(path)
        names = with_known_aliases(names)
        if error and error.startswith("fontTools unavailable"):
            fonttools_available = False
        record = {"path": str(path), "names": sorted(names)}
        inventory.append(record)
        if error:
            errors.append({"path": str(path), "error": error})
        for name in names:
            name_index.setdefault(normalize(name), []).append({"name": name, "path": str(path)})

    registry_entries = windows_registry_fonts()
    for entry in registry_entries:
        entry["names"] = sorted(with_known_aliases(entry["names"]))
        for name in entry["names"]:
            match = {"name": name, "path": entry["path"], "source": "Windows registry"}
            existing = name_index.setdefault(normalize(name), [])
            if match not in existing:
                existing.append(match)

    requirements: list[dict[str, Any]] = []
    missing: list[str] = []
    for required in args.require:
        matches = name_index.get(normalize(required), [])
        requirements.append({"required": required, "exact_normalized_match": bool(matches), "matches": matches})
        if not matches:
            missing.append(required)

    report = {
        "status": "PASS" if not missing else "BLOCKED",
        "platform": platform.platform(),
        "fonttools_available": fonttools_available,
        "font_directories": [str(path) for path in directories],
        "requirements": requirements,
        "missing": missing,
        "font_file_count": len(inventory),
        "registry_entry_count": len(registry_entries),
        "inventory": inventory,
        "inspection_errors": errors,
        "policy": "A fallback may be used only for a labeled draft; it is not exact-font compliance.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("status", "missing", "font_file_count")}, ensure_ascii=False))
    return 0 if not missing else 2


if __name__ == "__main__":
    sys.exit(main())

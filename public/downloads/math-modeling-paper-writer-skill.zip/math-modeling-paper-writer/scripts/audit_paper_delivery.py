#!/usr/bin/env python3
"""Machine-audit a mathematical-modeling paper before visual sign-off."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    from pypdf import PdfReader
    from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject
except ModuleNotFoundError as exc:
    raise SystemExit(
        "Missing dependency 'pypdf'. In Codex, load workspace dependencies and run this script "
        "with the bundled Python executable."
    ) from exc


PLACEHOLDER_PATTERNS: dict[str, re.Pattern[str]] = {
    "TODO": re.compile(r"\bTODO\b", re.IGNORECASE),
    "TBD": re.compile(r"\bTBD\b", re.IGNORECASE),
    "XXX": re.compile(r"\bXXX\b", re.IGNORECASE),
    "待补": re.compile(r"待补(?:充|写|图|表|数据)?"),
    "待定": re.compile(r"待定"),
}
LOG_ERROR_PATTERNS: dict[str, re.Pattern[str]] = {
    "undefined_reference": re.compile(r"(?:undefined references|Reference .+ undefined)", re.IGNORECASE),
    "undefined_citation": re.compile(r"Citation .+ undefined", re.IGNORECASE),
    "missing_character": re.compile(r"Missing character:", re.IGNORECASE),
    "font_not_found": re.compile(r"(?:fontspec error|font .+ not found|cannot find font)", re.IGNORECASE),
    "blocking_font_fallback": re.compile(r"PAPER-FONT-CHECK: BLOCKING FALLBACK ACTIVE", re.IGNORECASE),
}
LOG_WARNING_PATTERNS: dict[str, re.Pattern[str]] = {
    "overfull_box": re.compile(r"Overfull \\[hv]box", re.IGNORECASE),
    "underfull_box": re.compile(r"Underfull \\[hv]box", re.IGNORECASE),
    "rerun_needed": re.compile(r"Rerun to get cross-references right", re.IGNORECASE),
    "font_shape_substitution": re.compile(r"Font shape .+ undefined|font shapes were not available", re.IGNORECASE),
}
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}")
GRAPHICSPATH_RE = re.compile(r"\\graphicspath\s*\{((?:\{[^{}]*\})+)\}")
FULL_RULE_RE = re.compile(
    r"\\hrule\b|\\noindent\s*\\rule\s*\{\\(?:textwidth|linewidth)\}|"
    r"\\rule\s*\{\\(?:textwidth|linewidth)\}\s*\{[^}]+\}"
)
TABLE_OF_CONTENTS_RE = re.compile(r"\\tableofcontents\b")
BODY_START_RE = re.compile(
    r"(?m)^\s*(?:第?[一二三四五六七八九十]+[、.．]\s*)?"
    r"(?:问题重述|问题分析)|^\s*(?:1|一)[、.．\s]+\S"
)
APPENDIX_HEADING_RE = re.compile(
    r"(?m)^\s*附\s*录(?:\s|$|[A-ZＡ-Ｚ一二三四五六七八九十\d])"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def strip_comments(line: str) -> str:
    escaped = False
    output: list[str] = []
    for character in line:
        if character == "%" and not escaped:
            break
        output.append(character)
        if character == "\\":
            escaped = not escaped
        else:
            escaped = False
    return "".join(output)


def line_hits(path: Path, pattern: re.Pattern[str]) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    text = path.read_text(encoding="utf-8", errors="replace")
    for number, raw_line in enumerate(text.splitlines(), start=1):
        line = strip_comments(raw_line)
        if pattern.search(line):
            hits.append({"file": str(path), "line": number, "text": line.strip()[:300]})
    return hits


def resolve_graphic(tex_path: Path, value: str, search_directories: Iterable[Path]) -> Path | None:
    raw = Path(value.strip())
    candidates = [raw] if raw.is_absolute() else [tex_path.parent / raw]
    if not raw.is_absolute():
        candidates.extend(directory / raw for directory in search_directories)
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
        for suffix in (".pdf", ".png", ".jpg", ".jpeg", ".eps", ".svg"):
            extended = candidate.with_suffix(suffix)
            if extended.exists():
                return extended.resolve()
    return None


def dereference(value: Any) -> Any:
    while isinstance(value, IndirectObject):
        value = value.get_object()
    return value


def font_is_embedded(font: DictionaryObject) -> bool:
    descriptor = dereference(font.get("/FontDescriptor", DictionaryObject()))
    if isinstance(descriptor, DictionaryObject) and any(
        key in descriptor for key in ("/FontFile", "/FontFile2", "/FontFile3")
    ):
        return True
    descendants = dereference(font.get("/DescendantFonts", ArrayObject()))
    if isinstance(descendants, (ArrayObject, list, tuple)):
        for descendant_ref in descendants:
            descendant = dereference(descendant_ref)
            if isinstance(descendant, DictionaryObject) and font_is_embedded(descendant):
                return True
    return False


def collect_pdf_fonts(reader: PdfReader) -> list[dict[str, Any]]:
    fonts: dict[str, dict[str, Any]] = {}
    for page in reader.pages:
        resources = dereference(page.get("/Resources", DictionaryObject()))
        font_map = dereference(resources.get("/Font", DictionaryObject())) if resources else {}
        if not isinstance(font_map, DictionaryObject):
            continue
        for _, font_ref in font_map.items():
            font = dereference(font_ref)
            if not isinstance(font, DictionaryObject):
                continue
            base = str(font.get("/BaseFont", "UNKNOWN")).lstrip("/")
            embedded = font_is_embedded(font)
            fonts.setdefault(base, {"base_font": base, "embedded": embedded})
            fonts[base]["embedded"] = fonts[base]["embedded"] or embedded
    return sorted(fonts.values(), key=lambda item: item["base_font"])


def match_lines(text: str, patterns: dict[str, re.Pattern[str]]) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for name, pattern in patterns.items():
        matches = [line.strip() for line in text.splitlines() if pattern.search(line)]
        if matches:
            result[name] = matches[:100]
    return result


def add_issue(collection: list[dict[str, Any]], code: str, message: str, evidence: Any = None) -> None:
    issue: dict[str, Any] = {"code": code, "message": message}
    if evidence is not None:
        issue["evidence"] = evidence
    collection.append(issue)


def compact_text(text: str) -> str:
    return re.sub(r"\s+", "", text or "")


def centered_footer_numbers(page: Any) -> tuple[bool, list[str], list[dict[str, Any]]]:
    """Return Arabic-number fragments located near the bottom center of a PDF page."""
    fragments: list[dict[str, Any]] = []

    def visitor(text: str, cm: Any, tm: Any, _font: Any, size: Any) -> None:
        cleaned = compact_text(text)
        if not cleaned or not re.fullmatch(r"\d{1,3}", cleaned):
            return
        try:
            x = float(tm[4]) * float(cm[0]) + float(tm[5]) * float(cm[2]) + float(cm[4])
            y = float(tm[4]) * float(cm[1]) + float(tm[5]) * float(cm[3]) + float(cm[5])
            font_size = float(size or 0)
        except (IndexError, TypeError, ValueError):
            return
        fragments.append({"text": cleaned, "x": round(x, 2), "y": round(y, 2), "font_size": round(font_size, 2)})

    try:
        page.extract_text(visitor_text=visitor)
    except (TypeError, AttributeError, NotImplementedError):
        return False, [], []

    width = float(page.mediabox.width)
    height = float(page.mediabox.height)
    centered = [
        item for item in fragments
        if width * 0.30 <= item["x"] <= width * 0.70
        and -height * 0.05 <= item["y"] <= height * 0.15
    ]
    return True, [item["text"] for item in centered], centered


def find_appendix_physical_page(extracted: list[str]) -> int | None:
    """Find an appendix heading near the top of a page after the body starts."""
    for index, text in enumerate(extracted[2:], start=2):
        head = "\n".join((text or "").splitlines()[:12])
        if APPENDIX_HEADING_RE.search(head):
            return index + 1
    return None


def audit_cumcm_layout(
    reader: PdfReader,
    extracted: list[str],
    paper_title: str | None,
    body_page_limit: int,
    errors: list[dict[str, Any]],
    warnings: list[dict[str, Any]],
) -> dict[str, Any]:
    """Audit the cover/abstract/body/page-number contract for the national profile."""
    page_count = len(reader.pages)
    layout: dict[str, Any] = {
        "profile": "cumcm-national",
        "cover_physical_page": 1,
        "abstract_physical_page": 2,
        "body_start_physical_page": 3,
        "body_page_limit": body_page_limit,
        "appendix_start_physical_page": None,
        "body_page_count": None,
        "footer_page_numbers": [],
    }
    if page_count < 3:
        add_issue(errors, "CUMCM_TOO_FEW_PAGES", "National layout requires at least cover, abstract, and body pages", page_count)
        return layout

    page1 = compact_text(extracted[0])
    page2 = compact_text(extracted[1])
    page3_text = extracted[2] or ""
    page3 = compact_text(page3_text)

    if page1:
        if "摘要" in page1 or re.search(r"关键[词字]", page1):
            add_issue(errors, "COVER_CONTAINS_ABSTRACT", "Physical page 1 must be a standalone cover page")
    else:
        add_issue(warnings, "COVER_VISUAL_REQUIRED", "Cover text could not be extracted; verify physical page 1 visually")

    if "摘要" not in page2:
        add_issue(errors, "ABSTRACT_NOT_ON_PAGE2", "Physical page 2 does not contain 摘要")
    if not re.search(r"关键[词字]", page2):
        add_issue(errors, "KEYWORDS_NOT_ON_PAGE2", "Physical page 2 does not contain 关键词")
    if paper_title:
        if compact_text(paper_title).casefold() not in page2.casefold():
            add_issue(errors, "TITLE_NOT_ON_PAGE2", "Physical page 2 does not contain the requested paper title", paper_title)
    else:
        add_issue(warnings, "TITLE_TEXT_NOT_SUPPLIED", "Pass --paper-title to machine-check the title on physical page 2")

    if re.search(r"关键[词字]", compact_text(page3_text[:800])):
        add_issue(errors, "ABSTRACT_SPILLS_TO_PAGE3", "Keywords appear near the start of physical page 3; abstract-page content may have spilled")
    if not BODY_START_RE.search(page3_text):
        add_issue(errors, "BODY_NOT_STARTED_ON_PAGE3", "Physical page 3 does not show a recognizable body opening heading")
    appendix_page = find_appendix_physical_page(extracted)
    layout["appendix_start_physical_page"] = appendix_page
    if appendix_page is not None:
        body_page_count = appendix_page - 3
        if appendix_page <= 3:
            add_issue(errors, "APPENDIX_BEFORE_BODY", "Appendix must follow the body and references", appendix_page)
    else:
        body_page_count = page_count - 2
        add_issue(warnings, "APPENDIX_NOT_DETECTED", "No appendix heading was detected; body count uses every page after the abstract")
    layout["body_page_count"] = body_page_count
    if body_page_count > body_page_limit:
        add_issue(
            errors,
            "BODY_PAGE_LIMIT_EXCEEDED",
            f"Body including references exceeds {body_page_limit} pages",
            {"body_pages": body_page_count, "limit": body_page_limit, "appendix_page": appendix_page},
        )

    numbering_supported = True
    for index, page in enumerate(reader.pages):
        supported, numbers, fragments = centered_footer_numbers(page)
        numbering_supported = numbering_supported and supported
        physical_page = index + 1
        expected = None if physical_page == 1 else physical_page - 1
        layout["footer_page_numbers"].append(
            {"physical_page": physical_page, "expected": expected, "detected": numbers, "fragments": fragments}
        )
        if not supported:
            continue
        if physical_page == 1:
            if numbers:
                add_issue(errors, "COVER_PAGE_NUMBERED", "Cover page contains a centered footer number", numbers)
        elif str(expected) not in numbers:
            add_issue(
                errors,
                "CENTERED_PAGE_NUMBER_MISSING",
                "Expected continuous Arabic page number was not found at the footer center",
                {"physical_page": physical_page, "expected": expected, "detected": numbers},
            )
    if not numbering_supported:
        add_issue(errors, "PAGE_NUMBER_POSITION_UNVERIFIED", "PDF text coordinates could not verify footer-centered page numbers")

    return layout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--tex", type=Path, required=True)
    parser.add_argument("--pdf", type=Path, required=True)
    parser.add_argument("--log", type=Path)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--required-pdf-font", action="append", default=[])
    parser.add_argument("--allow-placeholder", action="append", default=[])
    parser.add_argument(
        "--layout-profile",
        choices=["cumcm-national", "generic"],
        default="cumcm-national",
        help="cumcm-national checks cover/abstract/body/page-number rules; generic skips them",
    )
    parser.add_argument("--body-page-limit", type=int, default=30)
    parser.add_argument("--paper-title", type=str)
    args = parser.parse_args()

    project = args.project.resolve()
    tex_main = args.tex.resolve()
    pdf_path = args.pdf.resolve()
    log_path = args.log.resolve() if args.log else None
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    checks: dict[str, Any] = {}

    if not project.exists():
        add_issue(errors, "PROJECT_MISSING", "Project directory does not exist", str(project))
    tex_files = sorted(project.rglob("*.tex")) if project.exists() else []
    checks["tex_files"] = [str(path) for path in tex_files]
    if tex_main not in [path.resolve() for path in tex_files]:
        add_issue(errors, "MAIN_TEX_MISSING", "Main TeX file was not found under the project", str(tex_main))

    placeholder_hits: dict[str, list[dict[str, Any]]] = {}
    duplicate_hits: list[dict[str, Any]] = []
    rule_hits: list[dict[str, Any]] = []
    raw_bold_hits: list[dict[str, Any]] = []
    contents_hits: list[dict[str, Any]] = []
    graphics: list[dict[str, Any]] = []
    graphic_search_dirs: list[Path] = [project, tex_main.parent]
    for tex_path in tex_files:
        content = tex_path.read_text(encoding="utf-8", errors="replace")
        for match in GRAPHICSPATH_RE.finditer(content):
            for value in re.findall(r"\{([^{}]*)\}", match.group(1)):
                graphic_search_dirs.extend([tex_path.parent / value, tex_main.parent / value, project / value])
    graphic_search_dirs = list(dict.fromkeys(path.resolve() for path in graphic_search_dirs))
    for tex_path in tex_files:
        for name, pattern in PLACEHOLDER_PATTERNS.items():
            if name.casefold() in {value.casefold() for value in args.allow_placeholder}:
                continue
            hits = line_hits(tex_path, pattern)
            if hits:
                placeholder_hits.setdefault(name, []).extend(hits)
        duplicate_hits.extend(line_hits(tex_path, re.compile(r"，，|。。|；；|：：|、、|\?\?|！！")))
        rule_hits.extend(line_hits(tex_path, FULL_RULE_RE))
        contents_hits.extend(line_hits(tex_path, TABLE_OF_CONTENTS_RE))
        raw_bold_hits.extend(line_hits(tex_path, re.compile(r"\\textbf\s*\{")))
        content = tex_path.read_text(encoding="utf-8", errors="replace")
        for match in GRAPHICS_RE.finditer(content):
            value = match.group(1)
            resolved = resolve_graphic(tex_path, value, graphic_search_dirs)
            graphics.append({"tex": str(tex_path), "reference": value, "resolved": str(resolved) if resolved else None})

    if placeholder_hits:
        add_issue(errors, "PLACEHOLDERS", "Unresolved placeholders exist in TeX sources", placeholder_hits)
    if duplicate_hits:
        add_issue(errors, "DUPLICATE_PUNCTUATION", "Suspicious duplicate punctuation exists", duplicate_hits)
    if rule_hits:
        add_issue(errors, "FULL_WIDTH_RULE", "Potential decorative full-width body rules exist", rule_hits)
    if args.layout_profile == "cumcm-national" and contents_hits:
        add_issue(errors, "TABLE_OF_CONTENTS_FORBIDDEN", "National paper profile must not generate a table of contents", contents_hits)
    if raw_bold_hits:
        add_issue(warnings, "RAW_TEXTBF", "Raw textbf commands should be reviewed in favor of semantic emphasis macros", raw_bold_hits)
    missing_graphics = [item for item in graphics if item["resolved"] is None]
    if missing_graphics:
        add_issue(errors, "MISSING_GRAPHICS", "Referenced graphics files are missing", missing_graphics)

    figure_hashes: dict[str, list[str]] = {}
    for item in graphics:
        if item["resolved"]:
            path = Path(item["resolved"])
            figure_hashes.setdefault(sha256(path), []).append(str(path))
    duplicate_figures = [paths for paths in figure_hashes.values() if len(set(paths)) > 1]
    if duplicate_figures:
        add_issue(warnings, "DUPLICATE_FIGURE_CONTENT", "Different figure paths have identical content", duplicate_figures)
    checks["graphics"] = graphics

    if log_path and log_path.exists():
        log_text = log_path.read_text(encoding="utf-8", errors="replace")
        log_errors = match_lines(log_text, LOG_ERROR_PATTERNS)
        log_warnings = match_lines(log_text, LOG_WARNING_PATTERNS)
        if log_errors:
            add_issue(errors, "LATEX_LOG_ERRORS", "LaTeX log contains blocking messages", log_errors)
        if log_warnings:
            add_issue(warnings, "LATEX_LOG_WARNINGS", "LaTeX log contains layout/rerun warnings", log_warnings)
        checks["log_sha256"] = sha256(log_path)
    elif log_path:
        add_issue(errors, "LOG_MISSING", "Requested LaTeX log does not exist", str(log_path))
    else:
        add_issue(warnings, "LOG_NOT_SUPPLIED", "No LaTeX log was supplied; compilation diagnostics were not audited")

    pdf_info: dict[str, Any] = {}
    if not pdf_path.exists() or pdf_path.stat().st_size == 0:
        add_issue(errors, "PDF_MISSING", "PDF is missing or empty", str(pdf_path))
    else:
        try:
            reader = PdfReader(str(pdf_path))
            page_count = len(reader.pages)
            pdf_info.update({"path": str(pdf_path), "bytes": pdf_path.stat().st_size, "sha256": sha256(pdf_path), "pages": page_count})
            if page_count == 0:
                add_issue(errors, "PDF_NO_PAGES", "PDF has no pages")
            dimensions: list[tuple[float, float]] = []
            extracted: list[str] = []
            for page in reader.pages:
                dimensions.append((round(float(page.mediabox.width), 2), round(float(page.mediabox.height), 2)))
                try:
                    extracted.append(page.extract_text() or "")
                except Exception:
                    extracted.append("")
            pdf_info["page_dimensions"] = sorted({f"{width}x{height}" for width, height in dimensions})
            pdf_info["fonts"] = collect_pdf_fonts(reader)
            if args.layout_profile == "cumcm-national":
                checks["cumcm_layout"] = audit_cumcm_layout(
                    reader,
                    extracted,
                    args.paper_title,
                    args.body_page_limit,
                    errors,
                    warnings,
                )
            else:
                page1 = compact_text(extracted[0]) if extracted else ""
                if page1:
                    if "摘要" not in page1:
                        add_issue(warnings, "ABSTRACT_NOT_ON_PAGE1_GENERIC", "Generic profile first page does not contain 摘要")
                    if not re.search(r"关键[词字]", page1):
                        add_issue(warnings, "KEYWORDS_NOT_ON_PAGE1_GENERIC", "Generic profile first page does not contain 关键词")
                else:
                    add_issue(warnings, "PAGE1_VISUAL_REQUIRED", "First-page text could not be extracted")
            joined_text = "\n".join(extracted)
            if "??" in joined_text:
                add_issue(errors, "PDF_UNRESOLVED_MARKERS", "Extracted PDF text contains ??")
            normalized_fonts = " ".join(item["base_font"] for item in pdf_info["fonts"]).casefold()
            for required in args.required_pdf_font:
                if required.casefold() not in normalized_fonts:
                    add_issue(errors, "REQUIRED_PDF_FONT_MISSING", f"Required PDF font was not found: {required}")
            unembedded = [item for item in pdf_info["fonts"] if not item["embedded"]]
            if unembedded:
                add_issue(warnings, "UNEMBEDDED_FONTS", "Some PDF fonts appear unembedded or use indirect composite resources", unembedded)
        except Exception as exc:
            add_issue(errors, "PDF_PARSE_ERROR", f"PDF could not be parsed: {type(exc).__name__}: {exc}")

    report = {
        "status": "FAIL" if errors else "PASS_MACHINE",
        "project": str(project),
        "main_tex": str(tex_main),
        "pdf": pdf_info,
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
        "manual_gates": [
            "Recompute every abstract number from the evidence ledger",
            "Visually confirm cover page, abstract page, body start, centered page numbers, body-page count, and appendix order",
            "Render and inspect every PDF page and critical figure at readable scale",
            "Verify exact required font family and embedding",
            "Verify optimum/robustness claims with the validation protocol",
            "Perform a clean end-to-end rebuild",
        ],
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": report["status"], "errors": len(errors), "warnings": len(warnings)}, ensure_ascii=False))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())

"""Render stratified PDF samples and build auditable contact sheets."""

from __future__ import annotations

import argparse
import json
import math
import re
import subprocess
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

try:
    from PIL import Image, ImageDraw, ImageFont
except ModuleNotFoundError as exc:
    raise SystemExit(
        "Missing dependency 'Pillow'. In Codex, load workspace dependencies and run this script "
        "with the bundled Python executable."
    ) from exc


def safe_name(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("_")[:90]


def font(size: int) -> ImageFont.ImageFont:
    for candidate in (
        Path(r"C:\Windows\Fonts\arial.ttf"),
        Path(r"C:\Windows\Fonts\msyh.ttc"),
    ):
        if candidate.is_file():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def render_page(poppler: Path, pdf: Path, page: int, dpi: int, output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    target = output.parent / f"{output.name}.png"
    if target.is_file() and target.stat().st_size > 1000:
        return target
    prefix = output
    command = [
        str(poppler), "-f", str(page), "-l", str(page), "-singlefile",
        "-png", "-r", str(dpi), str(pdf), str(prefix),
    ]
    completed = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if completed.returncode != 0 or not target.is_file():
        raise RuntimeError(
            f"pdftoppm failed for {pdf.name} page {page}: "
            f"{completed.stderr[-1200:]}"
        )
    return target


def make_sheet(
    images: list[tuple[Path, str]],
    output: Path,
    columns: int,
    thumb_width: int,
    label_height: int = 42,
) -> None:
    if not images:
        return
    prepared: list[tuple[Image.Image, str]] = []
    max_cell_height = 0
    for image_path, label in images:
        with Image.open(image_path) as opened:
            rgb = opened.convert("RGB")
            height = round(rgb.height * thumb_width / rgb.width)
            resized = rgb.resize((thumb_width, height), Image.Resampling.LANCZOS)
            prepared.append((resized, label))
            max_cell_height = max(max_cell_height, height + label_height)
    rows = math.ceil(len(prepared) / columns)
    margin = 18
    sheet = Image.new(
        "RGB",
        (columns * thumb_width + (columns + 1) * margin, rows * max_cell_height + (rows + 1) * margin),
        "white",
    )
    draw = ImageDraw.Draw(sheet)
    label_font = font(20)
    for index, (image, label) in enumerate(prepared):
        row, column = divmod(index, columns)
        x = margin + column * (thumb_width + margin)
        y = margin + row * max_cell_height
        draw.text((x, y), label[:75], fill="black", font=label_font)
        sheet.paste(image, (x, y + label_height))
        draw.rectangle(
            (x, y + label_height, x + image.width - 1, y + label_height + image.height - 1),
            outline=(160, 160, 160), width=1,
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, quality=92)


def chunks(items: list[Any], size: int) -> Iterable[list[Any]]:
    for start in range(0, len(items), size):
        yield items[start:start + size]


def representative(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_year: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in items:
        by_year[item["year"]].append(item)

    selected: list[dict[str, Any]] = []
    for year in sorted(by_year):
        group = sorted(by_year[year], key=lambda item: item["filename"])
        year_number = int(year) if str(year).isdigit() else 0
        if year_number >= 2023:
            for question in ("A", "B", "C", "D", "E"):
                candidates = [item for item in group if item["question"] == question]
                if candidates:
                    selected.append(candidates[len(candidates) // 2])
        else:
            page_median = sorted(item["pages"] for item in group)[len(group) // 2]
            selected.append(min(group, key=lambda item: (abs(item["pages"] - page_median), item["filename"])))

    for item in items:
        if item["filename"] == "2025B论文.pdf" and item not in selected:
            selected.append(item)
    return selected


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit", required=True, type=Path)
    parser.add_argument("--poppler", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    items = json.loads(args.audit.read_text(encoding="utf-8"))
    items = sorted(items, key=lambda item: (item["year"], item["question"], item["filename"]))
    args.out.mkdir(parents=True, exist_ok=True)

    first_page_images: list[tuple[Path, str]] = []
    for index, item in enumerate(items, start=1):
        pdf = Path(item["path"])
        rendered = render_page(
            args.poppler, pdf, 1, 72,
            args.out / "first_pages" / f"{index:03d}_{safe_name(item['filename'])}_p001",
        )
        first_page_images.append((rendered, f"{item['year']}-{item['question']} {item['filename']}"))
        print(f"first {index:03d}/{len(items):03d} {item['filename']}", flush=True)

    for sheet_index, group in enumerate(chunks(first_page_images, 20), start=1):
        make_sheet(
            group,
            args.out / "contact_first_pages" / f"first_pages_{sheet_index:02d}.jpg",
            columns=4,
            thumb_width=430,
            label_height=38,
        )

    selected = representative(items)
    selection_payload: list[dict[str, Any]] = []
    for sample_index, item in enumerate(selected, start=1):
        pdf = Path(item["path"])
        pages = sorted(set((1, min(2, item["pages"]), max(1, item["pages"] // 2), max(1, item["pages"] - 2))))
        rendered_pages: list[tuple[Path, str]] = []
        for page in pages:
            rendered = render_page(
                args.poppler, pdf, page, 110,
                args.out / "deep_pages" / f"{sample_index:02d}_{safe_name(item['filename'])}_p{page:03d}",
            )
            rendered_pages.append((rendered, f"{item['filename']} p.{page}/{item['pages']}"))
        make_sheet(
            rendered_pages,
            args.out / "contact_deep" / f"{sample_index:02d}_{safe_name(item['filename'])}.jpg",
            columns=2,
            thumb_width=760,
            label_height=42,
        )
        selection_payload.append({
            "filename": item["filename"], "path": item["path"], "year": item["year"],
            "question": item["question"], "pages": item["pages"], "sampled_pages": pages,
        })
        print(f"deep {sample_index:02d}/{len(selected):02d} {item['filename']} {pages}", flush=True)

    extra = next((item for item in items if item["filename"] == "2025B论文.pdf"), None)
    if extra:
        extra_images: list[tuple[Path, str]] = []
        for page in range(1, extra["pages"] + 1):
            rendered = render_page(
                args.poppler, Path(extra["path"]), page, 105,
                args.out / "extra_2025B_pages" / f"page_{page:03d}",
            )
            extra_images.append((rendered, f"2025B论文 p.{page}/{extra['pages']}"))
        for sheet_index, group in enumerate(chunks(extra_images, 4), start=1):
            make_sheet(
                group,
                args.out / "contact_extra_2025B" / f"2025B_{sheet_index:02d}.jpg",
                columns=2,
                thumb_width=760,
                label_height=42,
            )

    (args.out / "selection.json").write_text(
        json.dumps(selection_payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Wrote {args.out / 'selection.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

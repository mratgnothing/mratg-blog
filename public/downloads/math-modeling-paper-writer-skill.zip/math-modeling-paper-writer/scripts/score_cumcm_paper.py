#!/usr/bin/env python3
"""Validate a CUMCM internal paper scorecard and compute its evidence-gated status."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


EXPECTED_WEIGHTS = {
    "A_title_abstract_keywords": 20,
    "B_problem_restatement_and_analysis": 10,
    "C_assumptions_notation_model_logic": 15,
    "D_model_solution_reproducibility": 20,
    "E_results_validation_robustness": 15,
    "F_innovation_evaluation_generalization": 10,
    "G_figures_formulas_references_layout": 10,
}
EXPECTED_HARD_GATES = {
    "cover_is_physical_page_1",
    "cover_has_no_page_number",
    "abstract_is_physical_page_2",
    "abstract_page_contains_title_abstract_keywords",
    "abstract_fits_one_page",
    "printed_page_number_starts_at_1_on_physical_page_2",
    "printed_page_numbers_are_footer_center_and_continuous",
    "body_starts_on_physical_page_3",
    "table_of_contents_absent",
    "body_pages_including_references_at_most_30",
    "appendix_follows_body",
    "evidence_ledger_complete",
    "key_results_independently_recomputed",
    "figures_rebuild_from_frozen_data",
    "references_verified",
    "latex_log_has_no_blocking_error",
    "fonts_and_pdf_visuals_verified",
}
VALID_GATE_STATUSES = {"PASS", "FAIL", "PENDING"}


def issue(code: str, message: str, evidence: Any = None) -> dict[str, Any]:
    result: dict[str, Any] = {"code": code, "message": message}
    if evidence is not None:
        result["evidence"] = evidence
    return result


def validate_scorecard(data: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    if data.get("profile") != "cumcm-national":
        errors.append(issue("PROFILE_MISMATCH", "profile must be cumcm-national", data.get("profile")))

    gates = data.get("hard_gates")
    if not isinstance(gates, dict) or not gates:
        errors.append(issue("HARD_GATES_MISSING", "hard_gates must be a non-empty object"))
        gates = {}
    if set(gates) != EXPECTED_HARD_GATES:
        errors.append(
            issue(
                "HARD_GATE_SET",
                "hard gate names do not match the CUMCM profile",
                {
                    "missing": sorted(EXPECTED_HARD_GATES - set(gates)),
                    "unexpected": sorted(set(gates) - EXPECTED_HARD_GATES),
                },
            )
        )

    gate_status: dict[str, str] = {}
    for name, gate in gates.items():
        if not isinstance(gate, dict):
            errors.append(issue("GATE_SCHEMA", f"hard_gates.{name} must be an object"))
            continue
        status = str(gate.get("status", "")).upper()
        gate_status[name] = status
        if status not in VALID_GATE_STATUSES:
            errors.append(issue("GATE_STATUS", f"hard_gates.{name}.status must be PASS, FAIL, or PENDING", status))
        evidence = gate.get("evidence")
        if status == "PASS" and not str(evidence or "").strip():
            errors.append(issue("GATE_EVIDENCE_MISSING", f"hard_gates.{name} is PASS without evidence"))

    scores = data.get("scores")
    if not isinstance(scores, dict):
        errors.append(issue("SCORES_MISSING", "scores must be an object"))
        scores = {}
    if set(scores) != set(EXPECTED_WEIGHTS):
        errors.append(
            issue(
                "SCORE_DIMENSIONS",
                "score dimensions do not match the CUMCM rubric",
                {
                    "missing": sorted(set(EXPECTED_WEIGHTS) - set(scores)),
                    "unexpected": sorted(set(scores) - set(EXPECTED_WEIGHTS)),
                },
            )
        )

    total = 0.0
    complete_scores = True
    normalized_scores: dict[str, dict[str, Any]] = {}
    for name, expected_weight in EXPECTED_WEIGHTS.items():
        entry = scores.get(name, {})
        if not isinstance(entry, dict):
            errors.append(issue("SCORE_SCHEMA", f"scores.{name} must be an object"))
            complete_scores = False
            continue
        weight = entry.get("weight")
        if weight != expected_weight:
            errors.append(issue("WEIGHT_MISMATCH", f"scores.{name}.weight must equal {expected_weight}", weight))
        value = entry.get("score")
        if value is None:
            complete_scores = False
            normalized_scores[name] = {"weight": expected_weight, "score": None}
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append(issue("SCORE_TYPE", f"scores.{name}.score must be numeric or null", value))
            complete_scores = False
            continue
        if not 0 <= float(value) <= expected_weight:
            errors.append(issue("SCORE_RANGE", f"scores.{name}.score must be within [0, {expected_weight}]", value))
        evidence = entry.get("evidence")
        if not isinstance(evidence, list) or not any(str(item).strip() for item in evidence):
            errors.append(issue("SCORE_EVIDENCE_MISSING", f"scores.{name} needs at least one evidence item"))
        total += float(value)
        normalized_scores[name] = {"weight": expected_weight, "score": float(value)}

    failed_gates = sorted(name for name, status in gate_status.items() if status == "FAIL")
    pending_gates = sorted(name for name, status in gate_status.items() if status == "PENDING")
    all_gates_pass = bool(gates) and not failed_gates and not pending_gates and not errors

    if errors:
        verdict = "INVALID"
    elif failed_gates:
        verdict = "BLOCKED"
    elif pending_gates or not complete_scores:
        verdict = "DRAFT"
    elif all_gates_pass and total >= 90:
        verdict = "READY_FOR_FINAL_AUDIT"
    elif total >= 80:
        verdict = "REVISION_REQUIRED"
    elif total >= 70:
        verdict = "COMPLETE_DRAFT"
    else:
        verdict = "RESTRUCTURE_REQUIRED"

    lowest = None
    available = {name: value["score"] for name, value in normalized_scores.items() if value.get("score") is not None}
    if available:
        lowest = min(available, key=lambda name: available[name] / EXPECTED_WEIGHTS[name])

    if total >= 90 and not all_gates_pass:
        warnings.append(issue("HIGH_SCORE_GATES_NOT_PASSED", "A high score cannot override failed or pending hard gates"))

    return {
        "verdict": verdict,
        "total_score": round(total, 2) if complete_scores else None,
        "score_complete": complete_scores,
        "hard_gates_all_pass": all_gates_pass,
        "failed_gates": failed_gates,
        "pending_gates": pending_gates,
        "lowest_dimension": lowest,
        "scores": normalized_scores,
        "errors": errors,
        "warnings": warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scorecard", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    if not args.scorecard.exists():
        print(json.dumps({"verdict": "INVALID", "error": "scorecard missing"}, ensure_ascii=False))
        return 2
    try:
        data = json.loads(args.scorecard.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"verdict": "INVALID", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False))
        return 2
    if not isinstance(data, dict):
        print(json.dumps({"verdict": "INVALID", "error": "scorecard root must be an object"}, ensure_ascii=False))
        return 2

    report = validate_scorecard(data)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"verdict": report["verdict"], "total_score": report["total_score"], "errors": len(report["errors"])}, ensure_ascii=False))
    return 0 if report["verdict"] != "INVALID" else 2


if __name__ == "__main__":
    sys.exit(main())

"""Audit a corpus of Chinese mathematical-modeling papers.

The script extracts every page, records structural signals, and emits machine-
readable evidence for improving the paper-writing skill. It deliberately keeps
PDF extraction failures visible instead of silently treating them as absence.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

try:
    from pypdf import PdfReader
except ModuleNotFoundError as exc:
    raise SystemExit(
        "Missing dependency 'pypdf'. In Codex, load workspace dependencies and run this script "
        "with the bundled Python executable."
    ) from exc


FEATURES: dict[str, str] = {
    "abstract": r"摘\s*要",
    "keywords": r"关\s*键\s*[词字]",
    "problem_restated": r"问题\s*(重述|复述)",
    "problem_analysis": r"问题\s*分析",
    "model_assumptions": r"模型\s*假设|问题\s*假设|基本\s*假设",
    "symbols": r"符号\s*(说明|定义)|变量\s*说明",
    "model_building": r"模型\s*(建立|构建|建模)|建立\s*模型",
    "model_solution": r"模型\s*(求解|解法)|算法\s*(设计|求解)",
    "results": r"结果\s*(分析|展示|检验)|求解\s*结果|计算\s*结果",
    "validation": r"模型\s*(检验|验证)|结果\s*验证|正确性\s*检验",
    "sensitivity": r"灵敏度\s*分析|敏感性\s*分析",
    "robustness": r"鲁棒性\s*分析|稳健性\s*分析",
    "error_analysis": r"误差\s*分析|误差\s*估计",
    "strengths_weaknesses": r"模型\s*(优缺点|评价|推广)|优点\s*与\s*缺点|模型\s*改进",
    "references": r"参\s*考\s*文\s*献",
    "appendix": r"附\s*录",
    "contents": r"目\s*录",
    "flowchart": r"流程图|技术路线",
}

HEADING_RE = re.compile(
    r"^(?:第[一二三四五六七八九十百]+[章节]\s*[^\n]{1,35}|"
    r"[一二三四五六七八九十百]+、\s*[^\n]{1,35}|"
    r"\d+(?:\.\d+){0,3}\s+[^\n]{1,35})$"
)
YEAR_RE = re.compile(r"20(?:1[2-9]|2[0-5])")
QUESTION_RE = re.compile(r"(?:^|[-_\\/])([A-E])(?:题|[-_0-9])", re.IGNORECASE)
ALLOWED_TEXT_RE = re.compile(
    r"[\u3400-\u9fffA-Za-z0-9\s\u3000-\u303f\uff00-\uffef"
    r"\u0370-\u03ff\u2000-\u206f\u2070-\u209f\u2190-\u22ff\u00a0-\u024f]"
)


def clean_text(text: str) -> str:
    text = text.replace("\x00", "").replace("\u3000", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def unexpected_script_ratio(text: str) -> float:
    visible = [character for character in text if not character.isspace()]
    if not visible:
        return 0.0
    unexpected = sum(not ALLOWED_TEXT_RE.fullmatch(character) for character in visible)
    return unexpected / len(visible)


def infer_year(path: Path) -> str:
    filename_match = YEAR_RE.search(path.name)
    if filename_match:
        return filename_match.group(0)
    for part in reversed(path.parts):
        if re.fullmatch(YEAR_RE, part):
            return part
    return "unknown"


def infer_question(path: Path) -> str:
    for part in reversed(path.parts):
        direct = re.fullmatch(r"([A-E])题", part, re.IGNORECASE)
        if direct:
            return direct.group(1).upper()
    match = QUESTION_RE.search(str(path))
    if match:
        return match.group(1).upper()
    compact_match = re.search(r"20\d{2}[-_ ]?([A-E])", path.name, re.IGNORECASE)
    return compact_match.group(1).upper() if compact_match else "other"


def extract_abstract(first_pages: str) -> str:
    normalized = clean_text(first_pages)
    match = re.search(
        r"摘\s*要\s*[:：]?\s*(.*?)(?:关\s*键\s*[词字]\s*[:：]|\n\s*1[\.、\s])",
        normalized,
        flags=re.DOTALL,
    )
    if not match:
        return ""
    return re.sub(r"\s+", "", match.group(1))[:4000]


def extract_headings(text: str, limit: int = 80) -> list[str]:
    headings: list[str] = []
    seen: set[str] = set()
    for raw in text.splitlines():
        line = re.sub(r"\s+", " ", raw).strip(" .·•")
        if not (2 <= len(line) <= 55) or not HEADING_RE.match(line):
            continue
        if line not in seen:
            headings.append(line)
            seen.add(line)
        if len(headings) >= limit:
            break
    return headings


def pdf_paths(roots: Iterable[Path], extras: Iterable[Path]) -> list[Path]:
    paths: set[Path] = set()
    for root in roots:
        if root.is_dir():
            paths.update(path.resolve() for path in root.rglob("*.pdf"))
        elif root.suffix.lower() == ".pdf" and root.is_file():
            paths.add(root.resolve())
    for extra in extras:
        if extra.is_file() and extra.suffix.lower() == ".pdf":
            paths.add(extra.resolve())
    return sorted(paths, key=lambda path: str(path).lower())


def audit_pdf(path: Path) -> dict[str, Any]:
    result: dict[str, Any] = {
        "path": str(path),
        "filename": path.name,
        "year": infer_year(path),
        "question": infer_question(path),
        "file_bytes": path.stat().st_size,
        "pages": 0,
        "text_chars": 0,
        "ocr_required": False,
        "mojibake_suspected": False,
        "unexpected_script_ratio": 0.0,
        "extract_failed_pages": [],
        "features": {},
        "abstract_chars": 0,
        "figure_caption_count": 0,
        "table_caption_count": 0,
        "algorithm_mentions": 0,
        "equation_number_mentions": 0,
        "headings": [],
        "first_page_excerpt": "",
        "producer": "",
        "creator": "",
        "error": "",
    }
    try:
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            reader.decrypt("")
        result["pages"] = len(reader.pages)
        metadata = reader.metadata or {}
        result["producer"] = str(metadata.get("/Producer", ""))
        result["creator"] = str(metadata.get("/Creator", ""))
        page_texts: list[str] = []
        for index, page in enumerate(reader.pages):
            try:
                page_texts.append(clean_text(page.extract_text() or ""))
            except Exception as exc:  # keep page-level failures auditable
                result["extract_failed_pages"].append(
                    {"page": index + 1, "error": f"{type(exc).__name__}: {exc}"}
                )
                page_texts.append("")
        full_text = "\n".join(page_texts)
        compact_text = compact(full_text)
        result["text_chars"] = len(compact_text)
        result["ocr_required"] = result["text_chars"] < max(100, result["pages"] * 100)
        result["unexpected_script_ratio"] = unexpected_script_ratio("\n".join(page_texts[:3]))
        result["mojibake_suspected"] = result["unexpected_script_ratio"] > 0.08
        result["features"] = {
            name: bool(re.search(pattern, compact_text, flags=re.IGNORECASE))
            for name, pattern in FEATURES.items()
        }
        abstract = extract_abstract("\n".join(page_texts[:3]))
        result["abstract_chars"] = len(abstract)
        result["figure_caption_count"] = len(
            re.findall(r"(?:^|\n)\s*图\s*\d+(?:[-—.]\d+)?", full_text)
        )
        result["table_caption_count"] = len(
            re.findall(r"(?:^|\n)\s*表\s*\d+(?:[-—.]\d+)?", full_text)
        )
        result["algorithm_mentions"] = len(re.findall(r"算法\s*\d+", full_text))
        result["equation_number_mentions"] = len(
            re.findall(r"(?:式\s*[（(]?\d+[）)]?|[（(]\d+[）)])", full_text)
        )
        result["headings"] = extract_headings(full_text)
        result["first_page_excerpt"] = compact(page_texts[0])[:1000] if page_texts else ""
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def median(values: Iterable[int]) -> float:
    data = list(values)
    return float(statistics.median(data)) if data else 0.0


def rate(items: list[dict[str, Any]], feature: str) -> float:
    usable = [
        item for item in items
        if not item["error"] and not item["ocr_required"] and not item["mojibake_suspected"]
    ]
    if not usable:
        return 0.0
    return sum(bool(item["features"].get(feature)) for item in usable) / len(usable)


def write_summary(items: list[dict[str, Any]], output: Path) -> None:
    parsed = [item for item in items if not item["error"]]
    usable = [
        item for item in parsed
        if not item["ocr_required"] and not item["mojibake_suspected"]
    ]
    by_year: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_question: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in usable:
        by_year[item["year"]].append(item)
        by_question[item["question"]].append(item)

    lines = [
        "# 数学建模优秀论文语料审计",
        "",
        f"- PDF 总数：{len(items)}",
        f"- 成功读取页结构：{len(parsed)}",
        f"- 可用于语义统计：{len(usable)}",
        f"- 解析失败：{len(items) - len(parsed)}",
        f"- 总页数：{sum(item['pages'] for item in parsed)}",
        f"- 页数中位数：{median(item['pages'] for item in parsed):.1f}",
        f"- 摘要长度中位数：{median(item['abstract_chars'] for item in usable):.1f} 字",
        f"- 需要 OCR/视觉阅读：{sum(item['ocr_required'] for item in parsed)}",
        f"- 疑似乱码、需视觉阅读：{sum(item['mojibake_suspected'] for item in parsed)}",
        "",
        "## 核心结构出现率",
        "",
        "| 结构信号 | 论文数 | 比例 |",
        "|---|---:|---:|",
    ]
    for feature in FEATURES:
        count = sum(bool(item["features"].get(feature)) for item in usable)
        proportion = count / len(usable) if usable else 0.0
        lines.append(f"| {feature} | {count} | {proportion:.1%} |")

    lines.extend(
        [
            "",
            "## 按年份",
            "",
            "| 年份 | 篇数 | 页数中位数 | 摘要字数中位数 | 灵敏度 | 误差分析 | 模型评价 |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for year in sorted(by_year):
        group = by_year[year]
        lines.append(
            f"| {year} | {len(group)} | {median(i['pages'] for i in group):.1f} | "
            f"{median(i['abstract_chars'] for i in group):.1f} | {rate(group, 'sensitivity'):.1%} | "
            f"{rate(group, 'error_analysis'):.1%} | {rate(group, 'strengths_weaknesses'):.1%} |"
        )

    lines.extend(
        [
            "",
            "## 按题型",
            "",
            "| 题型 | 篇数 | 页数中位数 | 图题中位数 | 表题中位数 |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    order = ["A", "B", "C", "D", "E", "other"]
    for question in order:
        group = by_question.get(question, [])
        if not group:
            continue
        lines.append(
            f"| {question} | {len(group)} | {median(i['pages'] for i in group):.1f} | "
            f"{median(i['figure_caption_count'] for i in group):.1f} | "
            f"{median(i['table_caption_count'] for i in group):.1f} |"
        )

    failures = [
        item for item in items
        if item["error"] or item["extract_failed_pages"] or item["ocr_required"]
        or item["mojibake_suspected"]
    ]
    lines.extend(["", "## 提取异常", ""])
    if not failures:
        lines.append("无。")
    else:
        for item in failures:
            detail = item["error"]
            if not detail and item["extract_failed_pages"]:
                detail = f"失败页 {len(item['extract_failed_pages'])}"
            if not detail and item["ocr_required"]:
                detail = f"文本层不足（{item['text_chars']} 字），需 OCR 或视觉阅读"
            if not detail and item["mojibake_suspected"]:
                detail = (
                    f"疑似字体映射乱码（异常字符率 {item['unexpected_script_ratio']:.1%}），"
                    "需视觉阅读"
                )
            lines.append(f"- `{item['filename']}`：{detail}")

    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", action="append", default=[], type=Path)
    parser.add_argument("--extra", action="append", default=[], type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    paths = pdf_paths(args.root, args.extra)
    if not paths:
        print("No PDFs found.", file=sys.stderr)
        return 2

    args.out.mkdir(parents=True, exist_ok=True)
    items: list[dict[str, Any]] = []
    for index, path in enumerate(paths, start=1):
        print(f"[{index:03d}/{len(paths):03d}] {path.name}", flush=True)
        items.append(audit_pdf(path))

    json_path = args.out / "corpus_audit.json"
    json_path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")

    csv_path = args.out / "corpus_audit.csv"
    fieldnames = [
        "filename", "path", "year", "question", "file_bytes", "pages", "text_chars", "ocr_required",
        "mojibake_suspected", "unexpected_script_ratio",
        "abstract_chars", "figure_caption_count", "table_caption_count", "algorithm_mentions",
        "equation_number_mentions", "producer", "creator", "error",
    ] + list(FEATURES)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for item in items:
            row = {name: item.get(name, "") for name in fieldnames}
            row.update(item["features"])
            writer.writerow(row)

    write_summary(items, args.out / "corpus_summary.md")
    print(f"Wrote {json_path}")
    print(f"Wrote {csv_path}")
    print(f"Wrote {args.out / 'corpus_summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
